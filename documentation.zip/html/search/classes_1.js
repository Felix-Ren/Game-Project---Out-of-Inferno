var searchData=
[
  ['diedialog',['DieDialog',['../class_die_dialog.html',1,'']]]
];
