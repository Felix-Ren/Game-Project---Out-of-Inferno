var searchData=
[
  ['playerinfo',['playerInfo',['../classplayer_info.html',1,'playerInfo'],['../class_player_info.html',1,'PlayerInfo']]]
];
