var searchData=
[
  ['setlevel',['setLevel',['../class_player_info.html#ada68465b9dd1637832074c911cb984cc',1,'PlayerInfo']]],
  ['setlife',['setLife',['../class_player_info.html#a626e4f9e765a3c3a8587f3f62490c088',1,'PlayerInfo']]],
  ['show_5finstructions',['show_instructions',['../class_main_window.html#a5cec6b6f01af19126c4d9fa753e90e39',1,'MainWindow']]],
  ['stage',['Stage',['../class_stage.html',1,'']]],
  ['successdialog',['SuccessDialog',['../class_success_dialog.html',1,'']]],
  ['successdialog_2ecpp',['successdialog.cpp',['../successdialog_8cpp.html',1,'']]],
  ['successdialog_2eh',['successdialog.h',['../successdialog_8h.html',1,'']]]
];
