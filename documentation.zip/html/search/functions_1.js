var searchData=
[
  ['decreaselife',['decreaseLife',['../class_player_info.html#a011b279663bc7450373d18ca74cadbea',1,'PlayerInfo']]]
];
