var searchData=
[
  ['to_5fstage',['to_stage',['../class_main_window.html#a1cea2ee8252430951f59ed2ca3c8b362',1,'MainWindow']]],
  ['translate_5fto_5fchinese',['translate_to_Chinese',['../class_main_window.html#ac874aa9267f137bfb9896c9f1a011e64',1,'MainWindow']]],
  ['translate_5fto_5fenglish',['translate_to_English',['../class_main_window.html#ae439db1eb82d6ac61208d14ef939c725',1,'MainWindow']]]
];
