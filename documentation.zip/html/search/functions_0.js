var searchData=
[
  ['b4_5fto_5fb3',['B4_to_B3',['../class_b4.html#a8dc398bba0172fa78f650e1be88511fc',1,'B4']]],
  ['back_5fto_5fmain_5fmenu',['back_to_main_menu',['../class_success_dialog.html#aa3659427d4190ffb6516f3a32cd0ca18',1,'SuccessDialog']]]
];
