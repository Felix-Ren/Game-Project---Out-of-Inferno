var searchData=
[
  ['usespell',['useSpell',['../class_player_info.html#a0a3b54be1957ea4b0c4aa7d23ef8579e',1,'PlayerInfo']]]
];
