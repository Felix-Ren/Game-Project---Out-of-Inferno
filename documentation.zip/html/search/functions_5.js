var searchData=
[
  ['playerinfo',['PlayerInfo',['../class_player_info.html#a05e9b9529ed8e4638b2bd2fb76b3abeb',1,'PlayerInfo::PlayerInfo()'],['../class_player_info.html#a841143f69dd6ff3325c270fe4944435a',1,'PlayerInfo::PlayerInfo(QString levelName)']]]
];
